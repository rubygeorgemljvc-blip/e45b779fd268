# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(lldb-smoke src/lldb-smoke.cpp)
set_property(TARGET lldb-smoke PROPERTY CXX_STANDARD 11)
target_link_libraries(lldb-smoke lionss pthread)

add_executable(roundtrip-fuzz src/roundtrip-fuzz.cpp)
set_property(TARGET roundtrip-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(roundtrip-fuzz lionss pthread)

add_executable(verify-signatures src/verify-signatures.cpp)
set_property(TARGET verify-signatures PROPERTY CXX_STANDARD 11)
target_link_libraries(verify-signatures lionss pthread)

add_executable(linux-armv7 src/linux-armv7.cpp)
set_property(TARGET linux-armv7 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armv7 lionss pthread)

add_executable(dogfood src/dogfood.cpp)
set_property(TARGET dogfood PROPERTY CXX_STANDARD 11)
target_link_libraries(dogfood lionss pthread)

add_executable(linux-loongarch64 src/linux-loongarch64.cpp)
set_property(TARGET linux-loongarch64 PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-loongarch64 lionss pthread)

add_executable(gcc-latest src/gcc-latest.cpp)
set_property(TARGET gcc-latest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-latest lionss pthread)

add_executable(timeout-tests src/timeout-tests.cpp)
set_property(TARGET timeout-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(timeout-tests lionss pthread)

add_executable(live-tests src/live-tests.cpp)
set_property(TARGET live-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(live-tests lionss pthread)

add_executable(configure-defaults src/configure-defaults.cpp)
set_property(TARGET configure-defaults PROPERTY CXX_STANDARD 11)
target_link_libraries(configure-defaults lionss pthread)

add_executable(sonarcloud src/sonarcloud.cpp)
set_property(TARGET sonarcloud PROPERTY CXX_STANDARD 11)
target_link_libraries(sonarcloud lionss pthread)

add_executable(coverage-gate src/coverage-gate.cpp)
set_property(TARGET coverage-gate PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-gate lionss pthread)

add_executable(valgrind-memcheck src/valgrind-memcheck.cpp)
set_property(TARGET valgrind-memcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-memcheck lionss pthread)

add_executable(watchos-build src/watchos-build.cpp)
set_property(TARGET watchos-build PROPERTY CXX_STANDARD 11)
target_link_libraries(watchos-build lionss pthread)

add_executable(coroutines-check src/coroutines-check.cpp)
set_property(TARGET coroutines-check PROPERTY CXX_STANDARD 11)
target_link_libraries(coroutines-check lionss pthread)

add_executable(modules-build src/modules-build.cpp)
set_property(TARGET modules-build PROPERTY CXX_STANDARD 11)
target_link_libraries(modules-build lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(llvm-cov src/llvm-cov.cpp)
set_property(TARGET llvm-cov PROPERTY CXX_STANDARD 11)
target_link_libraries(llvm-cov lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(ios-arm64 src/ios-arm64.cpp)
set_property(TARGET ios-arm64 PROPERTY CXX_STANDARD 11)
target_link_libraries(ios-arm64 lionss pthread)

add_executable(binary-size src/binary-size.cpp)
set_property(TARGET binary-size PROPERTY CXX_STANDARD 11)
target_link_libraries(binary-size lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(cross-mingw64 src/cross-mingw64.cpp)
set_property(TARGET cross-mingw64 PROPERTY CXX_STANDARD 11)
target_link_libraries(cross-mingw64 lionss pthread)

add_executable(heap-profile src/heap-profile.cpp)
set_property(TARGET heap-profile PROPERTY CXX_STANDARD 11)
target_link_libraries(heap-profile lionss pthread)

add_executable(differential-fuzz src/differential-fuzz.cpp)
set_property(TARGET differential-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(differential-fuzz lionss pthread)

add_executable(format-diff src/format-diff.cpp)
set_property(TARGET format-diff PROPERTY CXX_STANDARD 11)
target_link_libraries(format-diff lionss pthread)

add_executable(trivy-scan src/trivy-scan.cpp)
set_property(TARGET trivy-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(trivy-scan lionss pthread)

add_executable(build-amalgamated src/build-amalgamated.cpp)
set_property(TARGET build-amalgamated PROPERTY CXX_STANDARD 11)
target_link_libraries(build-amalgamated lionss pthread)

