// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("migration tests"); }
int main(){
  announce();
  return lionss_run_workload("migration-tests");
}
