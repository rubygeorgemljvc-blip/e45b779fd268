// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("differential fuzz"); }
int main(){
  announce();
  return lionss_run_workload("differential-fuzz");
}
