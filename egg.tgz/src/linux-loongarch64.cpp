// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("linux loongarch64\n", stdout);
  return lionss_run_workload("linux-loongarch64");
}
