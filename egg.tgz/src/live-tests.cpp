// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("live tests\n", stdout);
  return lionss_run_workload("live-tests");
}
